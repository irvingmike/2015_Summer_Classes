This archive contains validation and 
tag-completion DTDs, templates and types 
for the following specifications:

- Connector 1.0 Deployment Descriptor
- EJB 2.0 Deployment Descriptor
- J2EE 1.3 Apllication Client Deployment Descriptor
- J2EE 1.3 Apllication Deployment Descriptor
- JSP 1.2 Tag Library Descriptor
- JSP
- Servlet 2.3 Deployment Descriptor

INSTALLATION INSTRUCTIONS:
--------------------------
To install the project unzip the '<project-name>.zip' 
file for windows users or untar/gzip the '<project-name>.tar.gz' 
file for Unix/Linux users to a preferred directory.

Now import the 'project.xngr' file in the Exchanger XML 
Editor by selecting the Project -> 'Import Project ...' 
menu item and select the 'project.xngr' file.
