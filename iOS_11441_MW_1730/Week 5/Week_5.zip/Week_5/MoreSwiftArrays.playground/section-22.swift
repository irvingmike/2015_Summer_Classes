
//students.sort(){
//    let lastFirst1 = "\($0.lastName)\($0.firstName)"
//    let lastFirst2 = "\($1.lastName)\($1.firstName)"
//    return lastFirst1 < lastFirst2
//}

