
numbers.sort(<)

print("\nSorted Numbers")
print(numbers)

