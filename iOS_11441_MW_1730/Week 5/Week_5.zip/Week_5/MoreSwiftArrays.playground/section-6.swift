
var student1 = Student(firstName: "Fred", lastName: "Smith", studentID: 12345)
var student2 = Student(firstName: "Susan", lastName: "Smith", studentID: 12341)
var student3 = Student(firstName: "John", lastName: "Black", studentID: 22222)
var student4 = Student(firstName: "Jill", lastName: "Jones", studentID: 11111)
var student5 = Student(firstName: "Bob", lastName: "Franklin", studentID: 33333)
var student6 = Student(firstName: "Joyce", lastName: "Smith", studentID: 12344)
var student7 = Student(firstName: "James", lastName: "Black", studentID: 12333)
var student8 = Student(firstName: "Fred", lastName: "Johnston", studentID: 55555)

