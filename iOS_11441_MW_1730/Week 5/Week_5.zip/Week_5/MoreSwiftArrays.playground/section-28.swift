
var numbers = [23, 99, 5, 87, 111, 54, 22, 76, 12, 100, 52, 78]

//numbers.sort(){$0 < $1}
//
//println("\nSorted Numbers")
//println(numbers)

