
var students = [student1, student2, student3, student4, student5, student6, student7, student8]

println("Before Sorting")
for student in students {
    println(student.description)
}

