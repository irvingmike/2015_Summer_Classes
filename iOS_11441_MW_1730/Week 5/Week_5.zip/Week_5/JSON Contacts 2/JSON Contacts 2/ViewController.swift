//
//  ViewController.swift
//  JSON Contacts 2
//
//  Created by Aaron Anderson on 7/27/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var contactsTextView: UITextView!
    
    var contacts = MyContacts()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        contacts.loadJSONContactsWithFileName("json-contacts")
        contacts.createJSONDictionary()
                
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        contactsTextView.text = contacts.description
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showAddContact" {
            let destination = segue.destinationViewController as! AddNewContactViewController
            destination.contacts = contacts
        }
    }

}

