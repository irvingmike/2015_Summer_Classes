//
//  Contacts.swift
//  JSON Contacts 1
//
//  Created by Aaron Anderson on 7/22/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Contact: Printable {
    
    var firstName: String
    var lastName: String
    var email: String
    var cell: String
    
    var description: String {
        return "\(firstName) \(lastName), \(email), \(cell)"
    }
    
    init(firstName: String, lastName: String, email: String, cell: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.cell = cell
    }
    
    convenience init(contactDictionary: NSDictionary) {
        self.init(firstName: (contactDictionary["firstName"] ?? "") as! String,
            lastName: (contactDictionary["lastName"] ?? "") as! String,
            email: (contactDictionary["email"] ?? "") as! String,
            cell: (contactDictionary["cell"] ?? "") as! String)
    }
}

class MyContacts: Printable {
    
    var jsonData: NSData
    var jsonArray: NSArray
    var contactsArray: [Contact]
    
    var description: String {
        var contacts = ""
        for contact in contactsArray {
            contacts += "\(contact)\n"
        }
        return contacts
    }
    
    init() {
        jsonData = NSData()
        jsonArray = []
        contactsArray = []
    }
    
    func addNewContactWithFirstName(firstName: String, lastName: String, email: String, cell: String) {
        
        contactsArray.append(Contact(firstName: firstName, lastName: lastName, email: email, cell: cell))
        
        contactsArray.sort{$0.lastName < $1.lastName}

    }
    
    func loadJSONContactsWithFileName(fileName: String) {
        
        let jsonURL = NSBundle.mainBundle().URLForResource(fileName, withExtension: "txt")
        
        if let urlCheck = jsonURL {
            jsonData = NSData(contentsOfURL: urlCheck)!
        }
        
        jsonArray = NSJSONSerialization.JSONObjectWithData(jsonData,
            options: NSJSONReadingOptions.MutableContainers,
            error: nil)! as! NSArray
    
    }
    
    func createJSONDictionary() {
        for json in jsonArray {
            let dictionary = json as! NSDictionary
            let contact = Contact(contactDictionary: dictionary)
            contactsArray.append(contact)
        }
        
        contactsArray.sort{$0.lastName < $1.lastName}
        
    }

}