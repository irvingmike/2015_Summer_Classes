//
//  main.swift
//  Exam1Project1
//
//  Created by Aaron Anderson on 7/27/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

func calculateSquareWithNumber(numberToSquare: Double) -> Double {
    return pow(numberToSquare, 2)
}

func calculateCubeWithNumber(numberToCube: Double) -> Double {
    return calculateSquareWithNumber(numberToCube) * numberToCube
}

func showSquareCubeWith(inputValue input: Double) {
    let squaredNumber: Double = calculateSquareWithNumber(input)
    let cubedNumber: Double = calculateCubeWithNumber(input)
    println("Input: \(input), Square: \(squaredNumber), Cube: \(cubedNumber)")
}

showSquareCubeWith(inputValue: 3.0)
showSquareCubeWith(inputValue: 4.0)
showSquareCubeWith(inputValue: 5.0)
showSquareCubeWith(inputValue: 10)
showSquareCubeWith(inputValue: 15.3)
showSquareCubeWith(inputValue: 18.9)