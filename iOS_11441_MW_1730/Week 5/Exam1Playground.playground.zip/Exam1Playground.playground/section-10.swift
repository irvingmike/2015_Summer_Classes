/* Question 4:

"It's not true." with a line break

*/
