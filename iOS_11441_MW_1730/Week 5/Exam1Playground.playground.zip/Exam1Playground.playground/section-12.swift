/* Question 5:

4. println(myFunction(inputOne: 5.5, inputTwo: 6))

*/
