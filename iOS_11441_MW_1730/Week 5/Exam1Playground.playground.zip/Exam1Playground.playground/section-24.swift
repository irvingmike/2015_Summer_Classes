/* Question 11:

2. var myPiano1 = Piano()

*/
