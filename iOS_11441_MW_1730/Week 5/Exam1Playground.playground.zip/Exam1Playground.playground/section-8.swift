/* Question 3: */

var stringVariable: String
stringVariable = "Fred"

