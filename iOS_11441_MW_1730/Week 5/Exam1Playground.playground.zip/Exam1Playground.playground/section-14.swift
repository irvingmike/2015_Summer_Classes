/* Question 6:

1. println("There are \(count) \(product)!")

*/
