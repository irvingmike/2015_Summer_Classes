/* Question 10:

4.
class Piano {
    var name = ""
}

*/
