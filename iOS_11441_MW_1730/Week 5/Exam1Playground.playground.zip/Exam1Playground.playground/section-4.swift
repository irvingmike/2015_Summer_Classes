/* Question 1:

3. let flag: Bit = 0x1

*/
