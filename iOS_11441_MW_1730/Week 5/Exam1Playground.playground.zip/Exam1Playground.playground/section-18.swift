/* Question 8:

2. [String]

*/
