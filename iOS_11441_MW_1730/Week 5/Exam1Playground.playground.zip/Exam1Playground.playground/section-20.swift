/* Question 9: */

var names = ["Bob", "Dakota", "Joe", "Ellen", "Josie", "Tim"]
for name in names {
    println("\(name)\n")
}


