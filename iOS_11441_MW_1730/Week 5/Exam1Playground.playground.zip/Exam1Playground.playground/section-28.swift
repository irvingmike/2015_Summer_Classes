/* Question 13:

int() {
    firstName = ""
    lastName = ""
}

*/
