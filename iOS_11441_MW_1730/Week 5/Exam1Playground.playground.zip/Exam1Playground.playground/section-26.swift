/* Question 12:

1. names.append("Sue")

*/
