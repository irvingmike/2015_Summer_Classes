/* Question 14: */

class Horn {
    init(){
    }
}

class Trombone: Horn {
    var values: Int
    
    override init() {
        values = 0
    }
}

