/* Question 2:

return, the function requires an interger be returned due to the -> Int

*/
