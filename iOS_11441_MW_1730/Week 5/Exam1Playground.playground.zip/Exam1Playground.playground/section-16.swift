/* Question 7: */

var firstName: String?
firstName = "Bill"
println(firstName!)


