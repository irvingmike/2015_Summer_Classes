// iOS Development Exam 1 – Summer 2015

import Foundation

let name = "Aaron Anderson"
let email = "irvingmichael@gmail.com"
let section = "2015 Summer MW 5:30pm"


