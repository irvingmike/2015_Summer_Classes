//
//  main.swift
//  Exam1Project2
//
//  Created by Aaron Anderson on 7/27/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

var ballArray: [Ball]
ballArray = []

ballArray.append(VolleyBall(circumference: 21.1, weight: 4.5, volleyBallColor: "blue/white"))
ballArray.append(VolleyBall(circumference: 15.3, weight: 6.3, volleyBallColor: "red"))
ballArray.append(BasketBall(circumference: 28.4, weight: 7.4, material: "leather"))
ballArray.append(BasketBall(circumference: 34.1, weight: 19.3, material: "vinyl"))

for ball in ballArray {
    ball.bounce()
}

for ball in ballArray {
    println(ball.description)
}