//
//  Ball.swift
//  Exam1Project2
//
//  Created by Aaron Anderson on 7/27/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Ball {
    var circumference: Double
    var weight: Double
    
    var description: String {
        return "circumference: \(circumference), weight: \(weight)"
    }
    
    init(circumfrence: Double, weight: Double) {
        self.circumference = circumfrence
        self.weight = weight
    }
    
    func bounce() {
        println("I'm bouncing the ball.")
    }
}

class VolleyBall: Ball {
    var volleyBallColor: String
    
    override var description: String {
        return "VolleyBall: \(super.description), color: \(volleyBallColor)"
    
    }
    
    init(circumference: Double, weight: Double, volleyBallColor: String) {
        self.volleyBallColor = volleyBallColor
        super.init(circumfrence: circumference, weight: weight)
    }
    
    override func bounce() {
        println("I'm bouncing the volleyball.")
    }
}

class BasketBall: Ball {
    var material: String
    
    override var description: String {
        return "BasketBall: material: \(material), \(super.description)"
        
    }

    init(circumference: Double, weight: Double, material: String) {
        self.material = material
        super.init(circumfrence: circumference, weight: weight)
    }
    
    override func bounce() {
        println("I'm bouncing the basketball.")
    }

}