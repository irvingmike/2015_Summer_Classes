//
//  Contacts.swift
//  JSON Contacts 1
//
//  Created by Aaron Anderson on 7/22/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Contact: CustomStringConvertible {
    
    var firstName: String
    var lastName: String
    var email: String
    var cell: String
    
    var description: String {
        return "\(firstName) \(lastName), \(email), \(cell)"
    }
    
    var fullName: String {
        return "\(firstName) \(lastName)"
    }
    
    var emailCell: String {
        return "\(email), cell: \(cell)"
    }
    
    init(firstName: String, lastName: String, email: String, cell: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.cell = cell
    }
    
    convenience init(contactDictionary: NSDictionary) {
        self.init(firstName: (contactDictionary["firstName"] ?? "") as! String,
            lastName: (contactDictionary["lastName"] ?? "") as! String,
            email: (contactDictionary["email"] ?? "") as! String,
            cell: (contactDictionary["cell"] ?? "") as! String)
    }
    
    convenience init() {
        self.init(firstName: "", lastName: "", email: "", cell: "")
    }
}

class MyContacts: CustomStringConvertible {
    
    var jsonData: NSData
    var jsonArray: NSArray
    var contactsArray: [Contact]
    
    var description: String {
        var contacts = ""
        for contact in contactsArray {
            contacts += "\(contact)\n"
        }
        return contacts
    }
    
    var count: Int {
        return contactsArray.count
    }
    
    init() {
        jsonData = NSData()
        jsonArray = []
        contactsArray = []
    }
    
    func addNewContactWithFirstName(firstName: String, lastName: String, email: String, cell: String) {
        
        contactsArray.append(Contact(firstName: firstName, lastName: lastName, email: email, cell: cell))
        
        contactsArray.sortInPlace{$0.lastName < $1.lastName}

    }
    
    func loadJSONContactsWithFileName(fileName: String) {
        
        let jsonURL = NSBundle.mainBundle().URLForResource(fileName, withExtension: "txt")
        
        if let urlCheck = jsonURL {
            jsonData = NSData(contentsOfURL: urlCheck)!
        }
        
        do {
            jsonArray = try NSJSONSerialization.JSONObjectWithData(jsonData,
                options: NSJSONReadingOptions.MutableContainers) as! NSArray
        } catch let error as NSError {
            print("Error: \(error.domain)")
        }
    }
    
    func createJSONDictionary() {
        for json in jsonArray {
            let dictionary = json as! NSDictionary
            let contact = Contact(contactDictionary: dictionary)
            contactsArray.append(contact)
        }
        
        contactsArray.sortInPlace{$0.lastName < $1.lastName}

    }
    
    func contactWithIndex(index: Int) -> Contact {
        return contactsArray[index] ?? Contact()
    }
    
    func sortContacts() {
    }
}
