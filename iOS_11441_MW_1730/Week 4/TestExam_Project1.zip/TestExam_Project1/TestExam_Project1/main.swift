//
//  main.swift
//  TestExam_Project1
//
//  Created by Aaron Anderson on 7/22/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

var personArray: [Person] = []

personArray.append(Person(name: "Aaron Anderson", phone: "111-222-3333", age: 42))
personArray.append(Person(name: "Jolly Bob", phone: "222-333-4444", age: 27))
personArray.append(Person(name: "Sherlock Holmes", phone: "333-444-5555", age: 63))
personArray.append(Person(name: "Herman Munster", phone: "444-555-6666", age: 56))

for person in personArray {
    println(person.description)
}
