//
//  Person.swift
//  TestExam_Project1
//
//  Created by Aaron Anderson on 7/22/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Person {
    var name: String
    var phone: String
    var age: Int
    
    var description: String {
        return "\(name), \(age), is reachable at \(phone)."
    }
    
    init(name: String, phone: String, age: Int) {
        self.name = name
        self.phone = phone
        self.age = age
    }
    
    convenience init() {
        self.init(name: "", phone: "", age: 0)
    }
}