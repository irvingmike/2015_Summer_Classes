//
//  ViewController.swift
//  Text Entry 2
//
//  Created by Aaron Anderson on 7/20/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var phrasesTextView: UITextView!
    
    var phrases = Phrases()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        phrases.addPhrase(textField.text)
        
        phrasesTextView.text = phrases.description
        textField.text = ""
        
        textField.resignFirstResponder()
        
        return true
    }


}

