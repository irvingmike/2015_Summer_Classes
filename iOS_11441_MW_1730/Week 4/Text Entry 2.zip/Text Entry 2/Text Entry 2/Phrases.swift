//
//  Phrases.swift
//  Text Entry 2
//
//  Created by Aaron Anderson on 7/20/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Phrases: Printable {
    
    var phrases: [String]
    
    var description: String {
        var allPhrases = ""
        allPhrases = "\n".join(phrases)
        return allPhrases
    }
    
    init (){
        phrases = []
    }
    
    func addPhrase(newPhrase: String) {
        if !newPhrase.isEmpty {
            phrases.append(newPhrase)
        }
    }
}