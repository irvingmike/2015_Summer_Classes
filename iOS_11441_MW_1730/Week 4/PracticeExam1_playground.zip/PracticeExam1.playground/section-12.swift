/* Question 5: */

let one = "Fred"
let two = 2

println("\(one) has \(two) apples.")

