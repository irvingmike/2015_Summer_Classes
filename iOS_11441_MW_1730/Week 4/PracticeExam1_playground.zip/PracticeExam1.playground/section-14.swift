/* Question 6: */

let number = 101

if !(number > 100) {
    println("The number is not bigger")
} else {
    println("The number is bigger")
}


