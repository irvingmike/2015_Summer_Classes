/* Question 1: */

var itemPrice: Double = 11.99

