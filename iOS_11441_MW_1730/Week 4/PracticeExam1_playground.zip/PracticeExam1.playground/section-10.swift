/* Question 4:

2. String

*/
