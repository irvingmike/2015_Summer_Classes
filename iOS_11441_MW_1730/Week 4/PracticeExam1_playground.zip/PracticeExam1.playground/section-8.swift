/* Question 3:

3. var three = 3

*/
