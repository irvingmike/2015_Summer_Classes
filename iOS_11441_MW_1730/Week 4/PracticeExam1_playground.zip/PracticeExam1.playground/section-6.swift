/* Question 2: */

func functionOne() {
    println("Hello")
}


