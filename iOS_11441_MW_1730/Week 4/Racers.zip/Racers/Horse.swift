//
//  Horse.swift
//  Racers
//
//  Created by Aaron Anderson on 7/21/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Horse: Raceable {
    
    var rider: String
    var height: Int
    var fed: Bool
    var startTime: NSDate
    var stopTime: NSDate
    
    init() {
        rider = ""
        height = 0
        fed = false
        startTime = NSDate()
        stopTime = NSDate()
    }
    
    func startRacing() {
        startTime = NSDate()
        sleep(1)
        println("The horse started racing at \(startTime).")
    }
    
    func stopRacing() {
        stopTime = NSDate()
        println("The horse started racing at \(startTime) and stopped at \(stopTime)")
    }

}