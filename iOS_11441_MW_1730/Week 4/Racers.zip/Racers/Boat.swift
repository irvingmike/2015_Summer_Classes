//
//  Boat.swift
//  Racers
//
//  Created by Aaron Anderson on 7/21/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Boat:Raceable {
    
    var passengers: Int
    var hullType: String
    var crewed: Bool
    var startTime: NSDate
    var stopTime: NSDate
    
    init() {
        passengers = 0
        hullType = ""
        crewed = false
        startTime = NSDate()
        stopTime = NSDate()
    }
    
    func startRacing() {
        startTime = NSDate()
        sleep(1)
        println("The boat started racing at \(startTime).")
    }
    
    func stopRacing() {
        stopTime = NSDate()
        println("The boat started racing at \(startTime) and stopped at \(stopTime)")
    }

}