//
//  Raceable.swift
//  Racers
//
//  Created by Aaron Anderson on 7/21/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

protocol Raceable {
    var startTime: NSDate { get set }
    var stopTime: NSDate { get set }
    
    func startRacing()
    func stopRacing()
}