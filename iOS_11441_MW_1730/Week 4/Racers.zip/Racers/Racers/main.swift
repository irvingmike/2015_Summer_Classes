//
//  main.swift
//  Racers
//
//  Created by Aaron Anderson on 7/21/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

//println("I have started!\n\n")

var raceableArray: [Raceable] = []

raceableArray.append(Bicycle())
raceableArray.append(Horse())
raceableArray.append(Boat())

for item in raceableArray {
    item.startRacing()
}

for item in raceableArray {
    item.stopRacing()
}

//println("\n\nI have finished!")
