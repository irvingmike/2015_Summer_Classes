//
//  Bicycle.swift
//  Racers
//
//  Created by Aaron Anderson on 7/21/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Bicycle: Raceable {
    
    var wheelSize: Int
    var clipless: Bool
    var manufacturer: String
    var startTime: NSDate
    var stopTime: NSDate
    
    init() {
        wheelSize = 0
        clipless = false
        manufacturer = ""
        startTime = NSDate()
        stopTime = NSDate()
    }
    
    func startRacing() {
        startTime = NSDate()
        sleep(1)
        println("The bicycle started racing at \(startTime).")
    }
    
    func stopRacing() {
        stopTime = NSDate()
        println("The bicycle started racing at \(startTime) and stopped at \(stopTime)")
    }
}