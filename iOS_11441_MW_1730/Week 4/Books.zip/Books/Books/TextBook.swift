//
//  TextBook.swift
//  Books
//
//  Created by Aaron Anderson on 7/21/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class TextBook: Book {
    
    var gradeLevel: String
    var subject: String
    var available: Bool
    
    init(title: String, isbn: String, pages: Int, yearPublished: Int, gradeLevel: String, subject: String, available: Bool) {
        self.gradeLevel = gradeLevel
        self.subject = subject
        self.available = available
        super.init(title: title, isbn: isbn, pages: pages, type: "Textbook", yearPublished: yearPublished)
    }
    
    convenience init () {
        self.init(title: "", isbn: "", pages: 0, yearPublished: 0, gradeLevel: "", subject: "", available: false)
    }
    
    override func readBook(title: String) -> String {
        return "The textbook, \(title), is being read."
    }

}
