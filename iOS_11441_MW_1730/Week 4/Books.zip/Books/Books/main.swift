//
//  main.swift
//  Books
//
//  Created by Aaron Anderson on 7/20/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

var booksArray: [Book] = []

booksArray.append(Book(title: "Ender's Game", isbn: "0-450-02576-4", pages: 263, type: "Ficition", yearPublished: 1959))
booksArray.append(Book(title: "Necronomicon", isbn: "0-666-00000-0", pages: 288, type: "Self-Improvement", yearPublished: 1924))
booksArray.append(CookBook(title: "The Perfect Scoop", isbn: "978-1580082198", pages: 256, recipeCount: 56, foodCatagory: "Dessert", yearPublished: 2010))
booksArray.append(CookBook(title: "Cookin’ with Coolio", isbn: "978-1439117613", pages: 224, recipeCount: 32, foodCatagory: "Getto", yearPublished: 2009))
booksArray.append(TextBook(title: "Year with the Yeti", isbn: "234-1562837268", pages: 287, yearPublished: 1987, gradeLevel: "Fist Year", subject: "Defence Against the Dark Arts", available: false))
booksArray.append(TextBook(title: "The Monster Book of Monsters", isbn: "017-8173MYH4ND", pages: 439, yearPublished: 1972, gradeLevel: "Third Year", subject: "Care of Magical Creatures", available: true))

for book in booksArray {
    println(book.readBook(book.title))
}