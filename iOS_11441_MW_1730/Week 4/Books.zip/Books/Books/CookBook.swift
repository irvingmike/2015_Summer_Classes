//
//  CookBook.swift
//  Books
//
//  Created by Aaron Anderson on 7/21/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class CookBook: Book {
    
    var recipeCount: Int
    var foodCatagory: String
    
    override var description: String {
        return "\(super.description), Food Catagory: \(foodCatagory), Number of Recipies: \(recipeCount)"
    }
    
    init(title: String, isbn: String, pages: Int, recipeCount: Int, foodCatagory: String, yearPublished: Int) {
        self.recipeCount = recipeCount
        self.foodCatagory = foodCatagory
        super.init(title: title, isbn: isbn, pages: pages, type: "Cookbook", yearPublished: yearPublished)
    }
    
    convenience init() {
        self.init(title: "", isbn: "", pages: 0, recipeCount: 0,  foodCatagory: "", yearPublished: 0)
    }
    
    override func readBook(title: String) -> String {
        return "The cookbook, \(title), is being read."
    }
}