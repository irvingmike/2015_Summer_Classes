//
//  Book.swift
//  Books
//
//  Created by Aaron Anderson on 7/20/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Book: Printable {
    var title: String
    var isbn: String
    var pages: Int
    var type: String
    var yearPublished: Int
    
    var description: String {
        return "\(type) - Title: \(title), ISBN: \(isbn), Pages: \(pages), Published: \(yearPublished)"
    }
    
    init(title: String, isbn: String, pages: Int, type: String, yearPublished: Int) {
        self.title = title
        self.isbn = isbn
        self.pages = pages
        self.type = type
        self.yearPublished = yearPublished
    }
    
    convenience init() {
        self.init(title: "", isbn: "", pages: 0, type: "", yearPublished: 0)
    }
    
    func readBook(title: String) -> String {
        return "The book, \(title), is being read."
    }
}