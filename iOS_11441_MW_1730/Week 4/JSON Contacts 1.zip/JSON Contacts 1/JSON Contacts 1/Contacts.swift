//
//  Contacts.swift
//  JSON Contacts 1
//
//  Created by Aaron Anderson on 7/22/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class Contact: Printable {
    
    var firstName: String
    var lastName: String
    var email: String
    var cell: String
    
    var description: String {
        return "\(firstName) \(lastName), \(email), \(cell)"
    }
    
    init(contactDictionary: NSDictionary) {
        firstName = (contactDictionary["firstName"] ?? "") as! String
        lastName = (contactDictionary["lastName"] ?? "") as! String
        email = (contactDictionary["email"] ?? "") as! String
        cell = (contactDictionary["cell"] ?? "") as! String
    }
}

class MyContacts: Printable {
    
    var jsonData: NSData
    var jsonArray: NSArray
    var contactsArray: [Contact]
    var descriptionString: String
    
    var description: String {
        for contact in contactsArray {
            descriptionString += "\(contact.firstName) \(contact.lastName), \(contact.email), \(contact.cell)\n"
        }
        return descriptionString
    }
    
    init() {
        jsonData = NSData()
        jsonArray = []
        contactsArray = []
        descriptionString = ""
    }
    
    func loadJSONContactsWithFileName(fileName: String) {
        
        let jsonURL = NSBundle.mainBundle().URLForResource(fileName, withExtension: "txt")
        
        if let urlCheck = jsonURL {
            jsonData = NSData(contentsOfURL: urlCheck)!
        }
        
        jsonArray = NSJSONSerialization.JSONObjectWithData(jsonData,
            options: NSJSONReadingOptions.MutableContainers,
            error: nil)! as! NSArray
        
    }
    
    func createJSONDictionary() {
        for json in jsonArray {
            let dictionary = json as! NSDictionary
            let contact = Contact(contactDictionary: dictionary)
            contactsArray.append(contact)
        }
    }
}