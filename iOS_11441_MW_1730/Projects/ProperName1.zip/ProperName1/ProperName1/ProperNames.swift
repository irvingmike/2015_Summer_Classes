//
//  ProperNames.swift
//  ProperName1
//
//  Created by Aaron Anderson on 7/9/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class ProperNames {
    let filePath: String
    let directoryPath: String
    
    var properNamesFile: String
    var namesFileArray: [String]
    var namesFiveOrLessCharacters: [String]
    var namesMoreThanFiveCharacters: [String]
    
    init(filePathToNamesFile: String) {
        filePath = filePathToNamesFile
        let fileNameSet = NSCharacterSet(charactersInString: "propernames")
        directoryPath = filePath.stringByTrimmingCharactersInSet(fileNameSet)
        
        properNamesFile = ""
        namesFileArray = []
        namesFiveOrLessCharacters = []
        namesMoreThanFiveCharacters = []
    }
    
    func importNamesFile(filePath: String) {
        properNamesFile = String(
            contentsOfFile: filePath,
            encoding: NSUTF8StringEncoding,
            error: nil)!
        namesFileArray = properNamesFile.componentsSeparatedByCharactersInSet(NSCharacterSet.newlineCharacterSet())
    }
    
    func sortNamesFile(namesFileArray: [String]) {
        for name in namesFileArray {
            if count(name) > 5 {
                namesMoreThanFiveCharacters.append(name)
            } else {
                namesFiveOrLessCharacters.append(name)
            }
        }
    }
    
    func writeOutputFiles() {
        var shortOutputString: String = ""
        var longOutputString: String = ""
        let shortFilePath = directoryPath + "shortProperNames"
        let longFilePath = directoryPath + "longProperNames"
        
        for name in namesFiveOrLessCharacters {
            shortOutputString += name + "\n"
        }
        
        if shortOutputString.writeToFile(shortFilePath, atomically: true, encoding: NSUTF8StringEncoding, error: nil) {
            println("Short File was saved successfully.")
        } else {
            println("Error saving the short file.")
        }
        
        for name in namesMoreThanFiveCharacters {
            longOutputString += name + "\n"
        }
        
        if shortOutputString.writeToFile(longFilePath, atomically: true, encoding: NSUTF8StringEncoding, error: nil) {
            println("Long File was saved successfully.")
        } else {
            println("Error saving the long file.")
        }

        
        
    }
}
