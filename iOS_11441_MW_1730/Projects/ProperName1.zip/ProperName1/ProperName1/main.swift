//
//  main.swift
//  ProperName1
//
//  Created by Aaron Anderson on 7/9/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

let pathToNamesFile = NSHomeDirectory() + "/Documents/Shared Playground Data/propernames"

let properNames = ProperNames(filePathToNamesFile: pathToNamesFile)

properNames.importNamesFile(pathToNamesFile)

properNames.sortNamesFile(properNames.namesFileArray)

properNames.writeOutputFiles()
