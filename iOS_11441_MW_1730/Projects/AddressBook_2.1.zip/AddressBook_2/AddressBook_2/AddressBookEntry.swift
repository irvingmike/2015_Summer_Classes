//
//  AddressBookEntry.swift
//  AddressBook
//
//  Created by Aaron Anderson on 7/1/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class AddressBookEntry: Printable {
    var firstName: String
    var lastName: String
    var email: String
    var addressesArray: [Address]
    var phoneNumberArray: [PhoneNumber]

    var description: String {
        var returnText: String = "Name: \(firstName) \(lastName)\nEmail: \(email)\n\n"
        for address in addressesArray {
            returnText += "\(address)\n"
            returnText += "\n"
        }
        for phoneNumber in phoneNumberArray {
            returnText += "\(phoneNumber)\n"
        }
        returnText += "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
        
        return(returnText)
    }
    
    init() {
        firstName = "<firstName>"
        lastName = "<lastName>"
        email = "<email>"
        addressesArray = []
        phoneNumberArray = []
    }
    
    convenience init(firstName: String, lastName: String, email: String) {
        self.init()
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
    }
    
    func addAddress(newAddress: Address) {
        addressesArray.append(newAddress)
    }
    
    func addPhoneNumber(newPhoneNumber: PhoneNumber) {
        phoneNumberArray.append(newPhoneNumber)
    }
}
