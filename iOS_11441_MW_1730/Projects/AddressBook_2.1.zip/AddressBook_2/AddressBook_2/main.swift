//
//  main.swift
//  AddressBook_2
//
//  Created by Aaron Anderson on 7/6/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

var entry1 = AddressBookEntry(firstName: "Aaron", lastName: "Anderson", email: "irvingmichael@gmail.com")
entry1.addAddress(Address(type: "Home", address1: "318 N. Owen Dr.", address2: "", city: "Madison", state: "WI", zipCode: "53705"))
entry1.addPhoneNumber(PhoneNumber(type: "Cell", areaCode: "608", number: "345-3491"))
entry1.addPhoneNumber(PhoneNumber(type: "Work", areaCode: "608", number: "831-6631"))

var entry2 = AddressBookEntry(firstName: "Sherlock", lastName: "Holmes", email: "sherlock@holmesdectiveagency.com")
entry2.addAddress(Address(type: "Home", address1: "221 Baker St.", address2: "Apt B", city: "London", state: "England", zipCode: "NW1 6XE"))

var newAddress = Address(type: "Work", address1: "I'm Board", address2: "6917 University Ave.", city: "Madison", state: "WI", zipCode: "53562")
entry1.addAddress(newAddress)
entry2.addAddress(newAddress)

var entry3 = AddressBookEntry(firstName: "Sheldon", lastName: "Cooper", email: "sheldon.cooper@caltech.edu")
entry3.addAddress(Address(type: "Home", address1: "2311 Los Robles Ave.", address2: "Apt 4A", city: "Pasadena", state: "CA", zipCode: "91105"))
entry3.addAddress(Address(type: "Work", address1: "California Institute of Technology", address2: "1200 E California Blvd", city: "Pasadena", state: "CA", zipCode: "91125"))
entry3.addPhoneNumber(PhoneNumber(type: "Work", areaCode: "626", number: "395-6811"))
entry3.addPhoneNumber(PhoneNumber(type: "Cell", areaCode: "626", number: "314-1592"))

var entry4 = AddressBookEntry(firstName: "Herman", lastName: "Munster", email: "hmunster@goodberryandgraves.com")
entry4.addAddress(Address(type: "Home", address1: "1313 Mockingbird Lane", address2: "", city: "Mockingbird Heights", state: "CA", zipCode: "91101"))
entry4.addAddress(Address(type: "Work", address1: "Gateman, Goodbury and Graves", address2: "104 Peaceful Rest Ln.", city: "Mockingbird Heights", state: "CA", zipCode: "91101"))
entry4.addPhoneNumber(PhoneNumber(type: "Work", areaCode: "313", number: "666-1313"))
entry4.addPhoneNumber(PhoneNumber(type: "Home", areaCode: "313", number: "Zenith9460"))

println(entry1.description)
println(entry2.description)
println(entry3.description)
println(entry4.description)
