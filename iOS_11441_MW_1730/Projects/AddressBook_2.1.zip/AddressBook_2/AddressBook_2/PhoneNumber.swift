//
//  PhoneNumber.swift
//  AddressBook_2
//
//  Created by Aaron Anderson on 7/6/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

struct PhoneNumber: Printable{
    let type: String
    let areaCode: String
    let number: String
    
    var description: String {
        return "\(type) Phone Number: (\(areaCode)) \(number)"
    }
}