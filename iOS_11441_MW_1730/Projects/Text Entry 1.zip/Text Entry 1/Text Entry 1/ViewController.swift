//
//  ViewController.swift
//  Text Entry 1
//
//  Created by Aaron Anderson on 7/8/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var outputLabel: UILabel!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        // println("In text field: \(textField.text).")
        
        outputLabel.text = textField.text
        textField.text = ""
        
        textField.resignFirstResponder()
        
        return true
    }
}

