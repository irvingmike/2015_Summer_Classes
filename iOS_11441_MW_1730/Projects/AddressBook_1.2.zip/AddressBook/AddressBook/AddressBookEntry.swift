//
//  AddressBookEntry.swift
//  AddressBook
//
//  Created by Aaron Anderson on 7/1/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class AddressBookEntry {
    var firstName: String = ""
    var lastName: String = ""
    var address: String = ""
    var city: String = ""
    var state: String = ""
    var email: String = ""
    
    func description() -> String {
        return "Address Book Entry - First Name: \(firstName), Last Name: \(lastName), Address: \(address), City: \(city), State: \(state), Email: \(email)"
    }
}
