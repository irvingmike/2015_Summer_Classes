//
//  main.swift
//  AddressBook
//
//  Created by Aaron Anderson on 7/1/15.
//  Copyright (c) 2015 Aaron Anderson. All rights reserved.
//

import Foundation

let addressBookEntry1 = AddressBookEntry()
addressBookEntry1.firstName = "Aaron"
addressBookEntry1.lastName = "Anderson"
addressBookEntry1.address = "318 N. Owen Dr."
addressBookEntry1.city = "Madison"
addressBookEntry1.state = "WI"
addressBookEntry1.email = "irvingmichael@gmail.com"

let addressBookEntry2 = AddressBookEntry()
addressBookEntry2.firstName = "Herman"
addressBookEntry2.lastName = "Munster"
addressBookEntry2.address = "1313 Mockingbird Lane"
addressBookEntry2.city = "Mockingbird Heights"
addressBookEntry2.state = "CA"
addressBookEntry2.email = "hmunster@goodberryandgraves.com"

let addressBookEntry3 = AddressBookEntry()
addressBookEntry3.firstName = "Morticia"
addressBookEntry3.lastName = "Adams"
addressBookEntry3.address = "0001 Cemetery Lane"
addressBookEntry3.city = "New York"
addressBookEntry3.state = "NY"
addressBookEntry3.email = "morticia@allsmilesdaycare.com"

let addressBookEntry4 = AddressBookEntry()
addressBookEntry4.firstName = "Sheldon"
addressBookEntry4.lastName = "Cooper"
addressBookEntry4.address = "2311 Los Robles Ave. Apt 4A"
addressBookEntry4.city = "Pasadena"
addressBookEntry4.state = "CA"
addressBookEntry4.email = "sheldon.cooper@caltech.edu"


var addressBookEntries: [AddressBookEntry] = [addressBookEntry1, addressBookEntry2, addressBookEntry3, addressBookEntry4]

for addressBookEntry in addressBookEntries {
    println(addressBookEntry.description())
}


