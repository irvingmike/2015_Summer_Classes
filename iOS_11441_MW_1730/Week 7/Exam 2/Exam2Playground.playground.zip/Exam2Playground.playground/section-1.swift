/* Question 1:

4. var dictionary4: [String : String] = [:]

*/
