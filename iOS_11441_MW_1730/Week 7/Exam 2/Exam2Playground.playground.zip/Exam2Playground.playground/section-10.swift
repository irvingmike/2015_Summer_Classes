/* Question 10:

When value is a variable that will hold a string.

*/
