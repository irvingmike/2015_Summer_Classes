/* Question 6:

var area: Double {
    
    return height x width
    
}

*/
