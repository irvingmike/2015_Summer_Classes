/* Question 7:

4. numbers.sort(<)

*/
