/* Question 2:

NSTimer
NSURLConnection

*/
