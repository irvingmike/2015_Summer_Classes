/* Question 13: */

var examDictionary: [Int:String] = [:]

examDictionary = [
    1: "one",
    2: "Two",
    3: "three",
    4: "four",
    5: "five"
]

