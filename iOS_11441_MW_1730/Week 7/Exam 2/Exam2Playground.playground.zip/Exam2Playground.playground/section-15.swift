/* Question 15: */

struct exam2Struct: Exam2 {
    let myProperty: String
}

