/* Question 3:

2. functionOne(name: "Bob", studentID: "abc123")

*/
