/* Question 11: */

protocol Exam2 {
    var myProperty: String { get }
}

