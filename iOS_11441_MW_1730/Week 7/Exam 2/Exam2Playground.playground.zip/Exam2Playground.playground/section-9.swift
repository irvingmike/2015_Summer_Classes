/* Question 9:

1.
let runLoop = NSRunLoop.currentRunLoop()
runLoop.run()

*/
