/* Question 5:

3.
override func functionTwo() -> Int {
    return 2
}

*/
