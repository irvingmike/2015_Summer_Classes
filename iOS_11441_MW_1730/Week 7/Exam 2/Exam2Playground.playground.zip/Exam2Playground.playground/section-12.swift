/* Question 12:

print("The name is \(name!)")

*/
