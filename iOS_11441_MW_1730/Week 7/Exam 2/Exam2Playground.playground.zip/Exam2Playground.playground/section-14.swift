/* Question 14:

2. It is a protocol.

*/
