/* Question 4:

3. An Objective-C NSDictionary.

*/
