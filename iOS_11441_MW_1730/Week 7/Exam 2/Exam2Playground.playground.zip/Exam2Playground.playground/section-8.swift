/* Question 8: 

1. It's a parameter that is a function with an Int as a parameter that doesn't return anything.

*/
