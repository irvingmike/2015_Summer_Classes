//
//  RandomNumberTableViewController.swift
//  Exam2Project2
//
//  Created by Aaron Anderson on 8/12/15.
//  Copyright © 2015 Aaron Anderson. All rights reserved.
//

import UIKit

class RandomNumberTableViewController: UITableViewController {

    override func viewDidLoad() {
        
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        
    }

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
        
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1000
        
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("RandomNumberCell", forIndexPath: indexPath)

        cell.textLabel?.text = "\(indexPath.row + 1): \(generateRandomNumber())"

        return cell
        
    }


    func generateRandomNumber() -> Int {
        
        var randomNumber: Int
        
        randomNumber = Int(arc4random_uniform(10000 + 1))
        
        return randomNumber
        
    }

}
