//
//  main.swift
//  Exam2Project1
//
//  Created by Aaron Anderson on 8/12/15.
//  Copyright © 2015 Aaron Anderson. All rights reserved.
//

import Foundation

let randomDisplay = MakeRandomNumber()

let minuteTimer = NSTimer.scheduledTimerWithTimeInterval(1,
    target: randomDisplay,
    selector: "outputLine",
    userInfo: nil,
    repeats: true)

let runLoop = NSRunLoop.currentRunLoop()
runLoop.run()

