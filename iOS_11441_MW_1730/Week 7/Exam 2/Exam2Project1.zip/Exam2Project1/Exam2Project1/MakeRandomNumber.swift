//
//  MakeRandomNumber.swift
//  Exam2Project1
//
//  Created by Aaron Anderson on 8/12/15.
//  Copyright © 2015 Aaron Anderson. All rights reserved.
//

import Foundation

class MakeRandomNumber: CustomStringConvertible {
    
    var numberCurrent: Int
    var numbersSum: Int
    var numbersCount: Int
    var numbersAverage: Double
    
    init() {
        numberCurrent = 0
        numbersSum = 0
        numbersCount = 0
        numbersAverage = 0
    }
    
    var description: String {
        return "Random Number: \(numberCurrent), Average: \(numbersAverage)"
    }
    
    @objc
    func outputLine() {
        numberCurrent = Int(arc4random_uniform(1000 + 1))
        numbersSum += numberCurrent
        numbersCount += 1
        numbersAverage = Double(numbersSum)/Double(numbersCount)
        print(self.description)
    }
    
}